/*
 * This class accepts input from JavaMailMain, creates a verified gmail 
 * session, formats the message with MimeMessage format, and transports.
 */
package com.mycompany.javamail;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.BodyPart;
import javax.mail.Multipart;
import javax.mail.Transport;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.activation.DataHandler;

/**
 * @author JakeTara
 */
public class JavaMailSend {
    
    public static void sendMail(String to, String sub, String msg, String filepath, final String user, final String pass) {
        Properties props = new Properties();
        
        //Set the properties of the mail server that sends the mail
        props.put("mail.smtp.host", "smtp.gmail.com");
        
        //Set default mail submission port for proper routing
        props.put("mail.smtp.port", "587");
        
        //Must have a verification of the account name and password
        props.put("mail.smtp.auth", "true");

        //Take existing insecure connection and upgrade it to a secure connection using SSL/TLS
        props.put("mail.smtp.starttls.enable", "true");
        
        //Initialize JavaMail session object using props
        Session session = Session.getDefaultInstance(props, new Authenticator() {
            //Set account information session
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, pass);
            }
        });

        try {
            //https://tools.ietf.org/html/rfc2045 -link for format of internet message bodies
            Message message = new MimeMessage(session);

            message.setFrom(new InternetAddress(user));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(sub);
            message.setText(msg);

            if (filepath != null) {
                //Adding attachment section
                BodyPart messageBodyPart = new MimeBodyPart();
                messageBodyPart.setText("Here's the file:");
                Multipart multipart = new MimeMultipart();
                multipart.addBodyPart(messageBodyPart);
                messageBodyPart = new MimeBodyPart();
                DataSource source = new FileDataSource(filepath);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(filepath);
                multipart.addBodyPart(messageBodyPart);
                message.setContent(multipart);
                //Attachment added
            }

            Transport.send(message);

            System.out.println("Mail sent!");

        } catch (MessagingException e) {
            System.out.println("Sending error!");

            throw new RuntimeException(e);
        }
    }
}
