/*
 * This app uses JavaMail to communicate to google's free public simple mail
 * transfer protocol server and uses the Maven repository to download nessessary
 * .jar files to run. A gmail account is required to send mail using this app. 
 * Limitations are set on the smtp.google.com host for each user. For more info 
 * go to: https://support.google.com/a/answer/166852?hl=en
 */
package com.mycompany.javamail;

import java.util.Scanner;

/**
 * @author JakeTara
 */
public class JavaMailMain {

    public static void main(String[] args) {
        javaMail();
    }
    
    private static void javaMail(){
        //Scanner used for email input
        Scanner sc = new Scanner(System.in);
        
        /*Go to 'Security' tab on google account and turn on 
        'Less secure app access' -otherwise use google api*/
        
        /*https://developers.google.com/gmail/api/quickstart/java 
        -for google api purposes to verify app with token gen.*/
        System.out.println("Gmail login credentials:"
                + "\nEnter user email address:");
        String user = sc.nextLine();
        System.out.println("Enter user password:");
        String pass = sc.nextLine();
        
        //Input for message body parts
        System.out.println("Enter recipient: ");
        String to = sc.nextLine();
        System.out.println("Enter subject: ");
        String subject = sc.nextLine();
        System.out.println("Enter message: ");
        String message = sc.nextLine();
        System.out.println("Enter attachment file path? (y/n): ");
        String option = sc.nextLine();
        
        //Attach a file using its directory path
        String filepath = null;
        if(option.equalsIgnoreCase("y")){
            System.out.println("Enter filepath: ");
            filepath = sc.nextLine();
        }
        
        //Use MIME format input and send mail
        JavaMailSend.sendMail(to, subject, message, filepath, user, pass);
    }
}
